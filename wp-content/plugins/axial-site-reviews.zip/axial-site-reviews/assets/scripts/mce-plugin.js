!function(o){"use strict";window.tinymce.PluginManager.add("glsr_shortcode",function(o){o.addCommand("GLSR_Shortcode",function(){GLSR.shortcode.create(o.id)})})}();
