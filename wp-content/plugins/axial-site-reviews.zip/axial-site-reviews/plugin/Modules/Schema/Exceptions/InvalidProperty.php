<?php

namespace GeminiLabs\SiteReviews\Modules\Schema\Exceptions;

use Exception;

class InvalidProperty extends Exception
{
}
