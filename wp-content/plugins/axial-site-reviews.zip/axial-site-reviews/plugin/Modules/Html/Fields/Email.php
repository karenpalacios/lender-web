<?php

namespace GeminiLabs\SiteReviews\Modules\Html\Fields;

class Email extends Text
{
}
