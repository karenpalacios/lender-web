<?php

namespace GeminiLabs\SiteReviews\Modules\Html\Fields;

class Url extends Text
{
}
