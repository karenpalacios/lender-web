<?php

namespace GeminiLabs\SiteReviews\Modules\Html\Fields;

class Radio extends Checkbox
{
}
