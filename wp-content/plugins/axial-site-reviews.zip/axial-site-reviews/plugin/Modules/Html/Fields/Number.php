<?php

namespace GeminiLabs\SiteReviews\Modules\Html\Fields;

class Number extends Field
{
    /**
     * @return array
     */
    public static function defaults()
    {
        return [
            'class' => 'small-text',
        ];
    }
}
