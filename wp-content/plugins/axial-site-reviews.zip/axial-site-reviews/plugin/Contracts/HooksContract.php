<?php

namespace GeminiLabs\SiteReviews\Contracts;

interface HooksContract
{
    /**
     * @return void
     */
    public function run();
}
