<?php defined('WPINC') || die; ?>

<table class="form-table">
    <tbody>
        {{ rows }}
    </tbody>
</table>
