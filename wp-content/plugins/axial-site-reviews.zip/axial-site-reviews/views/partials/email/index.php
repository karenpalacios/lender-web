<?php defined('WPINC') || die;

include trailingslashit(__DIR__).'header.php';
include trailingslashit(__DIR__).'body.php';
include trailingslashit(__DIR__).'footer.php';
