<?php defined('WPINC') || die; ?>

<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title><?= wp_specialchars_decode((string) get_option('blogname', ''), ENT_QUOTES); ?></title>
</head>
<body>
