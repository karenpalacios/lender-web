<?php defined('WPINC') || die; ?>

<div class="glsr-field form-group custom-control custom-checkbox {{ class }}">
    {{ field }}
    {{ label }}
    {{ errors }}
</div>
