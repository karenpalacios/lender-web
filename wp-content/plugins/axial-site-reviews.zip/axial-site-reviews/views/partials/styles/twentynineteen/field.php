<?php defined('WPINC') || die; ?>

<p class="glsr-field {{ class }}">
    {{ label }}
    {{ field }}
    {{ errors }}
</p>
