<?php defined('WPINC') || die; ?>

<p class="glsr-field {{ class }}">
    <span class="glsr-field-choice">
        {{ field }}
        {{ label }}
    </span>
    {{ errors }}
</p>
