<?php defined('WPINC') || die; ?>

<div class="glsr-form-message wpcf7-response-output wpcf7-validation-errors {{ class }}">
    {{ message }}
</div>
