<?php defined('WPINC') || die; ?>

<p class="glsr-field {{ class }}">
    {{ field }}
    {{ label }}
    {{ errors }}
</p>
