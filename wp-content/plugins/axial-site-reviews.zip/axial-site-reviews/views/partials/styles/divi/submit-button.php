<?php defined('WPINC') || die; ?>

<button type="submit" class="glsr-button et_pb_contact_submit et_pb_button">
    <span class="glsr-button-loading"></span>
    <span class="glsr-button-text" data-text="{{ text }}">{{ text }}</span>
</button>
