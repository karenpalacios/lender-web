<?php defined('WPINC') || die; ?>

<div class="glsr-form-wrap et_pb_contact">
    <form class="et_pb_contact_form clearfix {{ class }}" id="{{ id }}" method="post" enctype="multipart/form-data">
        {{ fields }}
        {{ submit_button }}
        {{ response }}
    </form>
</div>
