<?php defined('WPINC') || die; ?>

<p class="glsr-form-message et-pb-contact-message et_pb_contact_field {{ class }}">
    {{ message }}
</p>
