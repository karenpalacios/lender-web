<?php defined('WPINC') || die; ?>

<p class="glsr-field et_pb_contact_field {{ class }}">
    <span class="et_pb_contact_field_options_wrapper">
        <span class="et_pb_contact_field_options_list">
            <span class="et_pb_contact_field_checkbox">
                {{ field }}
                {{ label }}
            </span>
        </span>
    {{ errors }}
    </span>
</p>
