<?php defined('WPINC') || die; ?>

<p class="glsr-field et_pb_contact_field {{ class }}">
    {{ label }}
    {{ field }}
    {{ errors }}
</p>
