<?php defined('WPINC') || die; ?>

<div class="glsr-field form-group form-check {{ class }}">
    {{ field }}
    {{ label }}
    {{ errors }}
</div>
