<?php defined('WPINC') || die; ?>

<div class="glsr-field form-group {{ class }}">
    {{ label }}
    {{ field }}
    {{ errors }}
</div>
