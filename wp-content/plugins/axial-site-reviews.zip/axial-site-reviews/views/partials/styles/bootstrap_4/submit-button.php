<?php defined('WPINC') || die; ?>

<button type="submit" class="glsr-button btn btn-primary">
    <span class="glsr-button-loading"></span>
    <span class="glsr-button-text" data-text="{{ text }}">{{ text }}</span>
</button>
