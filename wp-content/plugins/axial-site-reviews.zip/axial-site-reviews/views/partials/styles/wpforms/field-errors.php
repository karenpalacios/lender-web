<?php defined('WPINC') || die; ?>

<span class="glsr-field-errors wpforms-error">
    {{ errors }}
</span>
