<?php defined('WPINC') || die; ?>

<div class="glsr-field wpforms-field wpforms-field-checkbox {{ class }}">
    <ul>
        <li>
            {{ field }}
            {{ label }}
        </li>
    </ul>
    {{ errors }}
</div>
