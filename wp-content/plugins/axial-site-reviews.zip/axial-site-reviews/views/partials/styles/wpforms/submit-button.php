<?php defined('WPINC') || die; ?>

<button type="submit" class="glsr-button button wpforms-submit">
    <span class="glsr-button-loading"></span>
    <span class="glsr-button-text" data-text="{{ text }}">{{ text }}</span>
</button>
