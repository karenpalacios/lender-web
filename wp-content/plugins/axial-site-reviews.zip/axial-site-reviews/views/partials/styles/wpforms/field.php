<?php defined('WPINC') || die; ?>

<div class="glsr-field wpforms-field {{ class }}">
    {{ label }}
    {{ field }}
    {{ errors }}
</div>
