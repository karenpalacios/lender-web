<?php defined('WPINC') || die; ?>

<div class="glsr-field-errors nf-error-wrap nf-error">
    <div class="nf-error-msg">
        {{ errors }}
    </div>
</div>
