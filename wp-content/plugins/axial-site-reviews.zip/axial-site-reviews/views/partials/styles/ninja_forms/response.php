 <?php defined('WPINC') || die; ?>

<div class="glsr-form-message nf-response-msg {{ class }}">
    {{ message }}
</div>
