<?php defined('WPINC') || die; ?>

<div class="glsr-form-message wpcf7-display-none wpcf7-response-output {{ class }}">
    {{ message }}
</div>
