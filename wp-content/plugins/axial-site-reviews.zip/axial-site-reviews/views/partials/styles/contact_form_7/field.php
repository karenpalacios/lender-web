<?php defined('WPINC') || die; ?>

<p class="glsr-field {{ class }}">
    {{ label }}
    <span class="wpcf7-form-control-wrap">
        {{ field }}
    </span>
    {{ errors }}
</p>
