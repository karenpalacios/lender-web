<?php defined('WPINC') || die; ?>

<p>
    <button type="submit" class="glsr-button wpcf7-form-control wpcf7-submit button">
        <span class="glsr-button-loading"></span>
        <span class="glsr-button-text" data-text="{{ text }}">{{ text }}</span>
    </button>
</p>
