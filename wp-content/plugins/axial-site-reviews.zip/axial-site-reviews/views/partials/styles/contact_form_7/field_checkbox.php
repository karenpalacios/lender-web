<?php defined('WPINC') || die; ?>

<p class="glsr-field {{ class }}">
    <span class="wpcf7-form-control-wrap">
        <span class="wpcf7-form-control wpcf7-checkbox">
            <span class="wpcf7-list-item ">
                {{ field }}
                <span class="wpcf7-list-item-label">
                    {{ label }}
                </span>
            </span>
        </span>
    </span>
    {{ errors }}
</p>
