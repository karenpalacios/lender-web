<?php defined('WPINC') || die; ?>

<span class="wpcf7-not-valid-tip">{{ errors }}</span>
