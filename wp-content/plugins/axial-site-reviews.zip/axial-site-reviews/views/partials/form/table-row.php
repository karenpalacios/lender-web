<?php defined('WPINC') || die; ?>

<tr class="glsr-field {{ class }}">
    <th scope="row">{{ label }}</th>
    <td>
        {{ field }}
    </td>
</tr>
