<div class="notice notice-warning is-dismissible">
    <p><?= __('Expect to see these add-ons released in the coming months! Thank you again for your continued patience.', 'site-reviews'); ?></p>
</div>
