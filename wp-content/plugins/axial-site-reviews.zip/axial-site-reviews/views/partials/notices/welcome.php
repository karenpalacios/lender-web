<div class="notice notice-info is-dismissible glsr-notice" data-dismiss="welcome">
    <p><?= $text; ?> &mdash; <a class="button button-small" href="<?= admin_url('edit.php?post_type='.glsr()->post_type.'&page=welcome#!whatsnew'); ?>">See what's new</a></p> 
</div>
