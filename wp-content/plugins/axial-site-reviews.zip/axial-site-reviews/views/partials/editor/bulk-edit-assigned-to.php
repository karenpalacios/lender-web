<?php defined('WPINC') || die; ?>

<fieldset class="inline-edit-col-right">
    <div class="inline-edit-col">
        <div class="inline-edit-group wp-clearfix">
            <label class="alignleft">
                <span class="title"><?= __('Assigned To', 'site-reviews'); ?></span>
                <span class="input-text-wrap">
                    <input type="number" name="assigned_to" class="inline-edit-menu-order-input">
                </span>
            </label>
        </div>
    </div>
</fieldset>
