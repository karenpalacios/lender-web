<?php defined('WPINC') || die; ?>
<span tabindex="0" data-id="<?= $ID; ?>" data-url="<?= $permalink; ?>"><?= $title; ?></span>
