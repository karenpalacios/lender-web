<span tabindex="0" data-entry='{{ data.entry }}'>{{ data.text }}</span>
