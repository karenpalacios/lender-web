<?php defined('WPINC') || die; ?>

<div class="glsr-form-wrap">
    <form class="{{ class }}" id="{{ id }}" method="post" enctype="multipart/form-data">
        {{ fields }}
        {{ response }}
        {{ submit_button }}
    </form>
</div>
