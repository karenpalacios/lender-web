<?php defined('WPINC') || die; ?>

<div class="glsr-review">
    {{ title }}
    {{ rating }}
    {{ date }}
    {{ assigned_to }}
    {{ content }}
    {{ avatar }}
    {{ author }}
    {{ response }}
</div>
