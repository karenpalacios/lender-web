<?php defined('WPINC') || die; ?>

<div class="glsr-reviews-wrap">
    <div class="{{ class }}" id="{{ id }}">
        {{ reviews }}
        {{ pagination }}
    </div>
</div>
