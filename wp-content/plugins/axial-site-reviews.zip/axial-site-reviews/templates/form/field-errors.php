<?php defined('WPINC') || die; ?>

<span class="glsr-field-error">
    {{ errors }}
</span>
