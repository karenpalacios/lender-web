<?php defined('WPINC') || die; ?>

<div class="glsr-form-message {{ class }}">
    {{ message }}
</div>
