<?php defined('WPINC') || die; ?>

<div class="glsr-field {{ class }}">
    {{ label }}
    {{ field }}
    {{ errors }}
</div>
