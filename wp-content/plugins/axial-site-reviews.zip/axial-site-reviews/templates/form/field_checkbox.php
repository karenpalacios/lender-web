<?php defined('WPINC') || die; ?>

<div class="glsr-field {{ class }}">
    <div class="glsr-field-choice">
        {{ field }}
        {{ label }}
    </div>
    {{ errors }}
</div>
