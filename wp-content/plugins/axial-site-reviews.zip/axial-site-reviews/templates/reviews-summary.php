<?php defined('WPINC') || die; ?>

<div class="glsr-summary-wrap">
    <div class="{{ class }}" id="{{ id }}">
        {{ rating }}
        {{ stars }}
        {{ text }}
        {{ percentages }}
    </div>
</div>
