<?php

return [
    ':star-empty' => glsr()->url('assets/images/star-empty.svg'),
    ':star-error' => glsr()->url('assets/images/star-error.svg'),
    ':star-full' => glsr()->url('assets/images/star-full.svg'),
    ':star-half' => glsr()->url('assets/images/star-half.svg'),
];
