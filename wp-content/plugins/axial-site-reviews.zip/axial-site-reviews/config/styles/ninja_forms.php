<?php

return [
    'fields' => [
        'input' => 'ninja-forms-field nf-element',
        'textarea' => 'ninja-forms-field nf-element',
    ],
];
