<?php

return [
    'fields' => [
        'label' => 'et_pb_contact_form_label',
    ],
];
