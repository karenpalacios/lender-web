<?php

return [
    'fields' => [
        'input' => 'wpforms-field-large',
        'label' => 'wpforms-field-label',
        'label_checkbox' => 'wpforms-field-label-inline',
        'label_radio' => 'wpforms-field-label-inline',
        'select' => 'wpforms-field-large',
        'textarea' => 'wpforms-field-large',
    ],
];
